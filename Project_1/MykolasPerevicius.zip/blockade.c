#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define BOARD_SIZE 6
#define NUM_FENCES 8

/* ANSI C (C89) boolean definitions */
typedef int bool;
#define true 1
#define false 0

/*
   Game details:
    - Board is 6×6 (internal rows 0..5, printed as 1..6; columns 0..5, printed as a–f).
    - Tortoise starts at internal (1,2) [printed row 2, column 'c'].
    - Hare starts at internal (5,3) [printed row 6, column 'd'].
    - Each player starts with NUM_FENCES fences.
    - A horizontal fence command "H x#" (e.g. "d2") is parsed so that base_col and base_row are obtained;
         then fence segments are placed in fences.horizontal[base_row][base_col] and [base_row][base_col+1].
    - A vertical fence command "V x#" (e.g. "c6") is parsed normally; then a fence is placed between
         columns base_col and base_col+1 at rows base_row-1 and base_row—that is, in fences.vertical[base_col+1][base_row]
         and fences.vertical[base_col+1][base_row-1].
*/

/* Structure for a player's token and fence count */
typedef struct {
    int row;   /* internal row (0 to BOARD_SIZE-1) */
    int col;   /* internal column (0 to BOARD_SIZE-1) */
    int fences_remaining;
} Player;

/* Structure for fence placements.
   horizontal[r][c] is true if a horizontal fence is placed between rows r-1 and r at column c.
   vertical[c][r] is true if a vertical fence is placed between columns c-1 and c at row r.
*/
typedef struct {
    bool horizontal[BOARD_SIZE][BOARD_SIZE];
    bool vertical[BOARD_SIZE][BOARD_SIZE];
} Fences;

static Player tortoise, hare;
static Fences fences;
static bool game_over = false;
static char winner = '\0';  /* 'T' for Tortoise, 'H' for Hare */

/* parse_position converts a coordinate (e.g. 'd','2') into internal indices.
   Valid if col letter is in 'a'..'f' and row digit in '1'..'6'. */
bool parse_position(char col_char, char row_char, int *col, int *row) {
    if (col_char < 'a' || col_char > 'f' || row_char < '1' || row_char > '6')
        return false;
    *col = col_char - 'a';
    *row = row_char - '1';
    return true;
}

/* is_path_to_goal uses a simple breadth-first search (ignoring jumps)
   to check that player p has a path to goal_row.
   For Tortoise, goal_row = BOARD_SIZE - 1; for Hare, goal_row = 0.
*/
bool is_path_to_goal(Player p, int goal_row) {
    int visited[BOARD_SIZE][BOARD_SIZE];
    int queue_r[BOARD_SIZE * BOARD_SIZE], queue_c[BOARD_SIZE * BOARD_SIZE];
    int front = 0, back = 0, i, j;
    for (i = 0; i < BOARD_SIZE; i++)
        for (j = 0; j < BOARD_SIZE; j++)
            visited[i][j] = 0;
    visited[p.row][p.col] = 1;
    queue_r[back] = p.row;
    queue_c[back] = p.col;
    back++;
    while (front < back) {
        int r = queue_r[front], c = queue_c[front];
        front++;
        if (r == goal_row)
            return true;
        if (r < BOARD_SIZE - 1 && !visited[r+1][c] && !fences.horizontal[r+1][c]) {
            visited[r+1][c] = 1;
            queue_r[back] = r+1;
            queue_c[back] = c;
            back++;
        }
        if (r > 0 && !visited[r-1][c] && !fences.horizontal[r][c]) {
            visited[r-1][c] = 1;
            queue_r[back] = r-1;
            queue_c[back] = c;
            back++;
        }
        if (c < BOARD_SIZE - 1 && !visited[r][c+1] && !fences.vertical[c+1][r]) {
            visited[r][c+1] = 1;
            queue_r[back] = r;
            queue_c[back] = c+1;
            back++;
        }
        if (c > 0 && !visited[r][c-1] && !fences.vertical[c][r]) {
            visited[r][c-1] = 1;
            queue_r[back] = r;
            queue_c[back] = c-1;
            back++;
        }
    }
    return false;
}

/* init_game initializes the game state:
   - Tortoise starts at internal (1,2); Hare at internal (5,3).
   - Each starts with NUM_FENCES fences.
   - All fence arrays are cleared.
*/
void init_game(void) {
    int i, j;
    tortoise.row = 1;
    tortoise.col = 2;
    tortoise.fences_remaining = NUM_FENCES;
    hare.row = 5;
    hare.col = 3;
    hare.fences_remaining = NUM_FENCES;
    for (i = 0; i < BOARD_SIZE; i++) {
        for (j = 0; j < BOARD_SIZE; j++) {
            fences.horizontal[i][j] = false;
            fences.vertical[i][j] = false;
        }
    }
    game_over = false;
    winner = '\0';
}

/* 
   Helper function: print_token_line prints the token line for a given internal row r.
   The board interior width is 27 characters. For each token in that row, we compute its ideal
   center position using: center = (col + 0.5) * (27.0 / BOARD_SIZE), then copy a 3-character token string
   (e.g. " T " or " H ") into the 27-character buffer (if the token is present). Finally, we print the line
   with an outer border.
*/
void print_token_line(int r) {
    char interior[28];  /* 27 characters plus terminating null */
    int i;
    /* Fill interior with spaces */
    for (i = 0; i < 27; i++)
        interior[i] = ' ';
    interior[27] = '\0';
    
    /* If Tortoise is on row r, place " T " centered in its cell */
    if (tortoise.row == r) {
        /* ideal center position for column tortoise.col: */
        double cell_width = 27.0 / BOARD_SIZE;  /* 4.5 */
        int center = (int)((tortoise.col + 0.5) * cell_width + 0.5);
        int start = center - 1;
        if (start < 0) start = 0;
        if (start + 3 > 27) start = 27 - 3;
        interior[start]   = ' ';
        interior[start+1] = 'T';
        interior[start+2] = ' ';
    }
    /* Similarly for Hare */
    if (hare.row == r) {
        double cell_width = 27.0 / BOARD_SIZE;
        int center = (int)((hare.col + 0.5) * cell_width + 0.5);
        int start = center - 1;
        if (start < 0) start = 0;
        if (start + 3 > 27) start = 27 - 3;
        interior[start]   = ' ';
        interior[start+1] = 'H';
        interior[start+2] = ' ';
    }
    printf("        |%s|\n", interior);
}

/* 
   print_board prints the entire board.
   It prints a header, column labels, a top border, then for each printed row pr (6 downto 1)
   it prints:
     (A) a token line (using print_token_line for that internal row),
     (B) a row line (showing cell gaps, vertical fence markers, and appended row information),
     (C) a separator line.
   Then it prints a bottom border, column labels, and a footer [S].
   The appended text in row lines is set to match the sample output.
*/
void print_board(void) {
    char line[256];
    int pr, col;
    
    /* Header */
    printf("                     [N]\n\n");
    printf("            a   b   c   d   e   f\n");
    printf("            |   |   |   |   |   |\n");
    printf("        +---------------------------+\n");
    
    for (pr = BOARD_SIZE; pr >= 1; pr--) {
        int r = pr - 1;
        /* (A) Token line */
        print_token_line(r);
        
        /* (B) Row line */
        sprintf(line, "     %d--|", pr);
        for (col = 0; col < BOARD_SIZE; col++) {
            if (r > 0 && fences.horizontal[r][col])
                strcat(line, "---");
            else
                strcat(line, "   ");
            if (col < BOARD_SIZE - 1) {
                if (fences.vertical[col+1][r])
                    strcat(line, "|");
                else
                    strcat(line, " +");
            }
        }
        sprintf(line + strlen(line), "|--%d", pr);
        if (pr == 6)
            strcat(line, "        Player (H)");
        else if (pr == 5)
            strcat(line, "        ==========");
        else if (pr == 3)
            strcat(line, "        Player (T)");
        else if (pr == 2)
            strcat(line, "        ==========");
        else if (pr == 1)
            strcat(line, "         | | |");
        printf("%s\n", line);
        
        /* (C) Separator line */
        strcpy(line, "        |");
        for (col = 0; col < BOARD_SIZE; col++) {
            if (r > 0 && fences.horizontal[r][col])
                strcat(line, "---");
            else
                strcat(line, "   ");
            if (col < BOARD_SIZE - 1) {
                if (fences.vertical[col+1][r])
                    strcat(line, "|");
                else
                    strcat(line, " +");
            }
        }
        strcat(line, "|");
        if (pr == 6) {
            strcat(line, "           Fences - ");
            {
                char tmp[10];
                sprintf(tmp, "%d", hare.fences_remaining);
                strcat(line, tmp);
            }
        } else if (pr == 3) {
            strcat(line, "           Fences - ");
            {
                char tmp[10];
                sprintf(tmp, "%d", tortoise.fences_remaining);
                strcat(line, tmp);
            }
        } else if (pr == 2) {
            strcat(line, "            | | | |");
        }
        printf("%s\n", line);
        
        if (pr == 4)
            printf("[W]     |                           |     [E]\n");
    }
    
    printf("        +---------------------------+\n");
    printf("            |   |   |   |   |   |\n");
    printf("            a   b   c   d   e   f\n\n");
    printf("                     [S]\n");
    
    if (game_over) {
        if (winner == 'T')
            printf("Tortoise wins!\n");
        else if (winner == 'H')
            printf("Hare wins!\n");
    }
}

/* 
   move_player moves the token one square in one of eight directions.
   Valid directions: N, S, E, W, NE, NW, SE, SW.
   (Jumping is not implemented.)
*/
bool move_player(Player *p, Player *opponent, const char *direction) {
    int dir_row = 0, dir_col = 0, new_r, new_c;
    if (strcmp(direction, "N") == 0) { dir_row = 1; dir_col = 0; }
    else if (strcmp(direction, "S") == 0) { dir_row = -1; dir_col = 0; }
    else if (strcmp(direction, "E") == 0) { dir_row = 0; dir_col = 1; }
    else if (strcmp(direction, "W") == 0) { dir_row = 0; dir_col = -1; }
    else if (strcmp(direction, "NE") == 0) { dir_row = 1; dir_col = 1; }
    else if (strcmp(direction, "NW") == 0) { dir_row = 1; dir_col = -1; }
    else if (strcmp(direction, "SE") == 0) { dir_row = -1; dir_col = 1; }
    else if (strcmp(direction, "SW") == 0) { dir_row = -1; dir_col = -1; }
    else return false;
    new_r = p->row + dir_row;
    new_c = p->col + dir_col;
    if (new_r < 0 || new_r >= BOARD_SIZE || new_c < 0 || new_c >= BOARD_SIZE)
        return false;
    if (opponent->row == new_r && opponent->col == new_c)
        return false;
    p->row = new_r;
    p->col = new_c;
    return true;
}

/* 
   place_fence processes a fence–placement command.
   For a horizontal fence ("H x#"): parse coordinate (base_col, base_row) and then
       set fences.horizontal[base_row][base_col] and fences.horizontal[base_row][base_col+1] to true.
   For a vertical fence ("V x#"): parse coordinate and then set fences.vertical[base_col+1][base_row]
       and fences.vertical[base_col+1][base_row-1] to true.
   A BFS check ensures that the opponent still has a valid path; if not, the fence is removed.
*/
bool place_fence(Player *p, char orientation, int base_col, int base_row) {
    int path_ok;
    if (p->fences_remaining <= 0)
        return false;
    if (orientation == 'H') {
        if (base_col < 0 || base_col >= BOARD_SIZE - 1 || base_row < 1 || base_row >= BOARD_SIZE)
            return false;
        if (fences.horizontal[base_row][base_col] && fences.horizontal[base_row][base_col+1])
            return false;
        fences.horizontal[base_row][base_col] = true;
        fences.horizontal[base_row][base_col+1] = true;
        if (p == &tortoise)
            path_ok = is_path_to_goal(hare, 0);
        else
            path_ok = is_path_to_goal(tortoise, BOARD_SIZE - 1);
        if (!path_ok) {
            fences.horizontal[base_row][base_col] = false;
            fences.horizontal[base_row][base_col+1] = false;
            return false;
        }
        p->fences_remaining--;
        return true;
    } else if (orientation == 'V') {
        if (base_col < 0 || base_col >= BOARD_SIZE - 1 || base_row < 1 || base_row >= BOARD_SIZE)
            return false;
        if (fences.vertical[base_col+1][base_row] && fences.vertical[base_col+1][base_row-1])
            return false;
        fences.vertical[base_col+1][base_row] = true;
        fences.vertical[base_col+1][base_row-1] = true;
        if (p == &tortoise)
            path_ok = is_path_to_goal(hare, 0);
        else
            path_ok = is_path_to_goal(tortoise, BOARD_SIZE - 1);
        if (!path_ok) {
            fences.vertical[base_col+1][base_row] = false;
            fences.vertical[base_col+1][base_row-1] = false;
            return false;
        }
        p->fences_remaining--;
        return true;
    }
    return false;
}

int main(int argc, char *argv[]) {
    FILE *fp;
    char line[100];
    int tortoise_turn = 1; /* 1: Tortoise's turn; 0: Hare's turn */
    int i;
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <commands_file>\n", argv[0]);
        return EXIT_FAILURE;
    }
    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        fprintf(stderr, "Error: Could not open file %s\n", argv[1]);
        return EXIT_FAILURE;
    }
    init_game();
    print_board();
    
    while (!game_over && fgets(line, sizeof(line), fp) != NULL) {
        int len = (int)strlen(line);
        if (len > 0 && line[len-1] == '\n') {
            line[len-1] = '\0';
            len--;
        }
        if (len == 0)
            continue;
        
        {
            Player *current, *opponent;
            char playerStr[10];
            if (tortoise_turn) {
                current = &tortoise;
                opponent = &hare;
                strcpy(playerStr, "Tortoise");
            } else {
                current = &hare;
                opponent = &tortoise;
                strcpy(playerStr, "Hare");
            }
            
            if (line[0] == 'H' || line[0] == 'V') {
                if (len < 3) {
                    printf("\n%s: %s (Invalid)\n", playerStr, line);
                } else {
                    char ori = line[0];
                    char col_char = line[2];
                    char row_char = line[3];
                    int base_col, base_row;
                    if (line[1] != ' ' || !isalpha(col_char) || !isdigit(row_char)) {
                        printf("\n%s: %s (Invalid)\n", playerStr, line);
                    } else {
                        if (parse_position(col_char, row_char, &base_col, &base_row)) {
                            if (ori == 'H') {
                                if (!place_fence(current, 'H', base_col, base_row))
                                    printf("\n%s: %s (Invalid)\n", playerStr, line);
                                else
                                    printf("\n%s: %s\n", playerStr, line);
                            } else {
                                if (!place_fence(current, 'V', base_col, base_row))
                                    printf("\n%s: %s (Invalid)\n", playerStr, line);
                                else
                                    printf("\n%s: %s\n", playerStr, line);
                            }
                        } else {
                            printf("\n%s: %s (Invalid)\n", playerStr, line);
                        }
                    }
                }
            } else {
                /* Movement command: extract up to 2 alphabetic characters and convert to uppercase */
                char move[3];
                int move_idx = 0;
                for (i = 0; i < len && i < 2; i++) {
                    if ((line[i] >= 'A' && line[i] <= 'Z') || (line[i] >= 'a' && line[i] <= 'z')) {
                        move[move_idx] = (char)((line[i] >= 'a' && line[i] <= 'z') ? line[i]-32 : line[i]);
                        move_idx++;
                    } else
                        break;
                }
                move[move_idx] = '\0';
                if (move_idx == 0)
                    printf("\n%s: %s (Invalid)\n", playerStr, line);
                else {
                    if (!move_player(current, opponent, move))
                        printf("\n%s: %s (Invalid)\n", playerStr, line);
                    else
                        printf("\n%s: %s\n", playerStr, line);
                }
            }
            
            /* Check win condition:
               - Tortoise wins if its token reaches the top (internal row BOARD_SIZE-1)
               - Hare wins if its token reaches the bottom (internal row 0)
            */
            if (current == &tortoise && current->row == BOARD_SIZE - 1) {
                game_over = true;
                winner = 'T';
            }
            if (current == &hare && current->row == 0) {
                game_over = true;
                winner = 'H';
            }
            
            print_board();
            
            if (game_over) {
                if (winner == 'T')
                    printf("\nTortoise wins!\n");
                else if (winner == 'H')
                    printf("\nHare wins!\n");
                break;
            }
            tortoise_turn = !tortoise_turn;
        }
    }
    fclose(fp);
    return EXIT_SUCCESS;
}
